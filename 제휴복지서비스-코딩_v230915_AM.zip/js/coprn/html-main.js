$(document).ready(function(){
	//상단 슬라이드 배너
	//var swiper = new Swiper(".thumbsText-slide", {
    //    slidesPerView: 'auto',
    //    freeMode: true,
    //    watchSlidesProgress: true,	
	//});
	var swiper2 = new Swiper(".topSlideBanner-slide", {
		slidesPerView: 'auto',     // 한 슬라이드에 보여줄 갯수
		//spaceBetween: 20,     // 슬라이드 사이 여백
		centeredSlides: true, //센터모드
		autoplay: {
		  delay: 5000,
		  disableOnInteraction: "false",
		},
		loop: true, //슬라이드 반복 여부
		loopAdditionalSlides: 1, //슬라이드 반복 시 마지막 슬라이드에서 다음 슬라이드가 보여지지 않는 현상 수정
		speed: 1000,
		pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          prevEl: ".swiper-button-prev",
          nextEl: ".swiper-button-next",
        },
		watchOverflow: true, // 슬라이드가 1개 일 때 pager, button 숨김 여부 설정
		//thumbs: {
		//  swiper: swiper,
		//}
	});
	
	
	//상단 이벤트 배너
	var swiper = new Swiper(".topEventBanner-slide", {
		slidesPerView: 1, // 한 슬라이드에 보여줄 갯수
		autoplay: {
		  delay: 5000,
		  disableOnInteraction: "false",
		},
		loop: true, //슬라이드 반복 여부
		loopAdditionalSlides: 1, //슬라이드 반복 시 마지막 슬라이드에서 다음 슬라이드가 보여지지 않는 현상 수정
		speed: 1000,
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        navigation: {
          prevEl: ".swiper-button-prev",
          nextEl: ".swiper-button-next",
        },
		watchOverflow: true // 슬라이드가 1개 일 때 pager, button 숨김 여부 설정
	});
	
	
	//최저가 상품 목록
	var swiper = new Swiper(".picksProduct-slide", {
		slidesPerView: 'auto',     // 한 슬라이드에 보여줄 갯수
		autoplay: {
		  delay: 5000,
		  disableOnInteraction: "false",
		},
		loop: true, //슬라이드 반복 여부
		loopAdditionalSlides: 1, //슬라이드 반복 시 마지막 슬라이드에서 다음 슬라이드가 보여지지 않는 현상 수정
		speed: 1000,
	  	navigation: {
          prevEl: ".swiper-button-prev",
          nextEl: ".swiper-button-next",
        },
	});
});